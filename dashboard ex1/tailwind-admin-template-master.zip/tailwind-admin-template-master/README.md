# Tailwind Admin Template

This is an admin dashboard template buit with [Tailwind](https://tailwindcss.com/) and [Alpine.js](https://github.com/alpinejs/alpine). This is inspired by the dribbble shots of [Vishnu Prasad](https://dribbble.com/shots/11085023-Medical-Dashboard) and [Filip Justić](https://dribbble.com/shots/10965359-Workly-My-Tasks-List).

View the demo [here](https://davidgrzyb.github.io/tailwind-admin-template/) 😎

<img src="screenshot.png" alt="Admin Dashboard Screenshot">
